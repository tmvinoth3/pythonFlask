import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session
import os
import datetime
#import bcrypt

app = Flask(__name__)
conn = sqlite3.connect("social.db")
#conn.execute("create table post(id integer primary key autoincrement, status text, image text, date_posted datetime, user_id integer);")
#conn.execute("create table like(id integer primary key, post_id integer, like_by user_id)")
#conn.execute("create table comment(id integer primary key, post_id integer, comment text ,comment_by user_id)")
#conn.execute("create table user(id integer primary key, username text, password text, dob datetime, gender text, country text, email text)")
#conn.execute("create table request(id integer primary key, from_id integer, to_id integer)")
#conn.execute("create table friend(id integer primary key, from_id integer, to_id integer)")


@app.route('/',methods=['POST','GET'])
def login():
    if request.method == 'GET':
            return render_template('social_login.html')
    elif request.method == 'POST':
            uname = request.form['uname']
            #pwd = hash(request.form['pwd'])

            #users = conn.execute("select * from users where username='{}' and password='{}'".format(uname,pwd))
            users = conn.execute("select * from user where username='{}'".format(uname))
            dictUsers = [dict(id=item[0],username=item[1],password=item[2]) for item in users]
            if len(dictUsers) == 0:
                return render_template('social_login.html',msg=0)
            else:
              #return str(len(dictUsers))
              res = dictUsers[0]
              print("Check Password {}".format(request.form['pwd'].encode('utf-8')))
              #if bcrypt.check_password_hash(res['password'],request.form['pwd'].encode('utf-8')):
              #if bcrypt.checkpw(request.form['pwd'].encode('utf-8'),res['password'].encode('utf-8')):
              if request.form['pwd'] == res['password']:
                  session[res['username']] = True
                  session['user'] = res['username']
                  session['user_id'] = res['id']
                  print("Check UserID => ",session['user_id'])
                  return redirect(url_for('create'))
              else:
                  return render_template('social_login.html',msg=0)

@app.route('/signup',methods=['POST','GET'])
def signup():
    if request.method == 'GET':
            return render_template('social_signup.html')
    elif request.method == 'POST':
            
            uname = request.form['uname']
            pwd = request.form['pwd']
            
            pwdConfirm = request.form['pwdConf']
            print("CheckPassConf: ",pwdConfirm)
            if 'gender' in request.form:
                gender = request.form['gender']
            print("CheckGender: ",gender)
            country = request.form['country']
            dob = request.form['dob']
            email = request.form['email']
            print("CheckEmail: ",email)
            if pwd != pwdConfirm:
                return render_template('signup.html',msg='Password Mismatch')
            #pwd = bcrypt.generate_password_hash(request.form['pwd'].encode('utf-8'))
            #pwd = bcrypt.hashpw(request.form['pwd'].encode('utf-8'), bcrypt.gensalt())
            
            users = conn.execute("select * from user where username='{}'".format(uname))
            dictUsers = [dict(id=item[0]) for item in users]
            #print(dictUsers,len(dictUsers))
            if len(dictUsers) == 0:
                conn.execute("insert into user (username,password,dob,gender,country,email) values ('{}','{}','{}','{}','{}','{}')".format(uname,pwd,dob,gender,country,email))
                conn.commit()
                return redirect(url_for('login'))
            else:
                return render_template('social_signup.html',msg='Username already exists')

@app.route('/logout/<string:user>',methods=['GET','POST'])
def logout(user):
    if request.method == 'POST':
        return login()
    else:
        session[user] = False
        return render_template('social_login.html',msg=2)

@app.route('/notLogged/<int:msg>')
def notLogged(msg):
    return render_template('social_login.html',msg=msg)

@app.route('/home')
def display():
  posts = conn.execute("select * from post where user_id in(select f.to_id from post p join friend f on p.user_id=f.from_id) or user_id={}".format(session['user_id']))
  post = [dict(id=p[0],status=p[1],image=p[2],date=p[3]) for p in posts]
  #post.update({'id': session['user_id'], 'key 3': 'value 3'})
  userQuery = conn.execute("select * from user where id not in(select r.to_id from user u join request r on u.id=r.from_id)")
  users = [dict(id=u[0],username=u[1]) for u in userQuery]
  myRequestQuery = conn.execute("select * from user where id in(select r.from_id from user u join request r on u.id=r.to_id)")
  reqUsers = [dict(id=r[0],username=r[1]) for r in myRequestQuery]
  return render_template('displayHome.html',post=post,users=users,reqUsers = reqUsers)

@app.route("/post",methods=['POST','GET'])
def create():
 if request.method == 'GET':
  return render_template('post.html')
 else:
  print("Check Before datetime")
  #post_date = datetime.datetime.now()
  post_date = datetime.datetime.now().strftime("%B %d, %Y %I:%M%p")
  file = request.files['image'];
  #conn.execute("insert into post (status,image,date_posted) values ('{}','{}','{}')".format(request.form['status'], "img/{}".format(request.form['image']),post_date))
  conn.execute("insert into post (status,image,date_posted,user_id) values ('{}','{}','{}',{})".format(request.form['status'], "img/{}".format(file.filename),post_date,session['user_id']))
  conn.commit()
  return redirect(url_for('display'))

@app.route("/sendRequest",methods=['POST'])
def sendRequest():
    if request.method == 'POST':
      print("Send Request")
      conn.execute("insert into request (from_id,to_id) values ({},{})".format(session['user_id'],data.toId))
      conn.commit()
    return "Success"

@app.route("/acceptRequest",methods=['POST'])
def acceptRequest():
    if request.method == 'POST':
      print("Accept Request")
      conn.execute("insert into friend (from_id,to_id) values ({},{})".format(session['user_id'],request.json['toId']))
      conn.execute("delete from request where from_id={} and to_id={}".format(session['user_id'],request.json['toId']))
      conn.commit()
    return "Success"


if __name__ == "__main__":
 app.secret_key = os.urandom(12)
 app.run('localhost',port=86)

conn.close()

