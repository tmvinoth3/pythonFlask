from flask import Flask, render_template, render_template_string
from random import randint
app = Flask(__name__)

books = {
	'APJ': {
	'author' : 'APJ Abdul Kalam',
	'name' : 'Wing Of Fire'
	},
	'Dhoni':{
	'author' : 'MS.Dhone',
	'name' : 'Returns Of CSK'
	}
}
 
@app.route("/hello")
def hello():
    return "Hello World!"
	
@app.route("/hello/<string:name>/")
def printName(name):
    return name

@app.route("/wohtmlfile/")
def withoutHtmlFile():
 books = ["Wings Of Fire", "Two States", "M.S.Dhoni"]
 html = "<html>{body}</html>"
 li = "<ul>"
 li += "\n".join(["<li>{book}</li>".format(book=b) for b in books])
 li += "</ul>"
 return html.format(body=li)
 
@app.route("/htmlPython/")
def htmlPython():
 books = ["Wings Of Fire", "Two States", "M.S.Dhoni"]
 html = """<html>
 <ul>
 {%for book in books%}
 <li>{{book}} </li>
 {%endfor%}
 </ul>
 </html>"""
 return render_template_string(html,books=books)
	
@app.route("/display/<string:name>/")
def displayHtml(name):
    return render_template('display.html',displayName = name)

@app.route("/quote/<string:name>/")
def displayQuote(name):
 quote = ["No Pain No Gain", "Work More Talk Less", "Time is gold"]
 index = randint(0,len(quote)-1)
 q = quote[index]
 return render_template('display.html',**locals())
 
