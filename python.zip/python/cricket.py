import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session
import os
import bcrypt

conn = sqlite3.connect('cricket.db')
print("Opened DB Successfully")

app = Flask(__name__)

@app.before_request 
def beforeRequest():
 print('Before Request Called')

@app.route('/',methods=['POST','GET'])
def login():
    if request.method == 'GET':
            return render_template('login.html')
    elif request.method == 'POST':
            print("Post called")
            uname = request.form['uname']
            pwd = hash(request.form['pwd'])
            users = conn.execute("select * from users where username='{}' and password='{}'".format(uname,pwd))
            dictUsers = [dict(username=item[1],password=item[2]) for item in users]
            print(dictUsers,len(dictUsers))
            if len(dictUsers) == 0:
                return render_template('login.html',msg=0)
            else:
              session['logged'] = True
              return redirect(url_for('display'),uName=dictUsers[0].username)   

@app.route('/signup',methods=['POST','GET'])
def signup():
    if request.method == 'GET':
            return render_template('signup.html')
    elif request.method == 'POST':
            uname = request.form['uname']
            salt = bcrypt.gensalt()
            pwd = hash(request.form['pwd'])
            users = conn.execute("select * from users where username='{}'".format(uname))
            dictUsers = [dict(id=item[0]) for item in users]
            print(dictUsers,len(dictUsers))
            if len(dictUsers) == 0:
                conn.execute("insert into users (username,password) values ('{}','{}')".format(uname,pwd))
                conn.commit()
                return redirect(url_for('login',msg=1))
            else:
                return render_template('signup.html',msg='Username already exists')

@app.route('/logout')
def logout():
    return redirect(url_for('login',msg=2))

@app.route('/display')
def display():
  persons = conn.execute("select * from player_info")
  person = [dict(id=p[0],name=p[1],country=p[2]) for p in persons]
  return render_template('displayPersons.html',person = person)

@app.route("/form",methods=['POST','GET','PUT'])
def create():
 if request.method == 'GET':
  return render_template('form.html')
 elif request.method == "POST":
  args = {'name' : request.form['name'],'country':request.form['country'],'born':request.form['born'],'role':request.form['role'],'image':'..img/{}'.format(request.form['country'])}
  conn.execute("insert into player_info (name,country,born,role,image_path) values('{}','{}','{}','{}','{}')".format(request.form['name'], request.form['country'], request.form['born'], request.form['role'], "img/{}".format(request.form['image'])))
  conn.commit()
  print("..img/{}".format(request.form['image']))
  return render_template('form.html')

@app.route("/update",methods=['GET','POST'])
def updateForm():
 if request.method == 'GET':
  return render_template('updateForm.html')
 elif request.method == "POST":
  conn.execute("update person set name='{}',country='{}' where id={}".format(request.form['name'], request.form['country'], request.form['id']))
  conn.commit()
  return redirect(url_for('display')) 

@app.route("/deletePerson/<int:id>")
def delete(id):
 conn.execute("delete from player_info where id='{}'".format(id))
 conn.commit()
 return redirect(url_for('display'))
 
@app.route("/updatePerson/<int:id>",methods=['POST','GET'])
def update(id):
 if request.method == "POST":
  image = request.form['image']
  if image == "":
      image = request.form['imageOld']
  else:
      image = "img/{}".format(image)
  conn.execute("update player_info set name='{}',country='{}',born='{}',role='{}',image_path='{}' where id={}".format(request.form['name'], request.form['country'], request.form['born'], request.form['role'], image ,request.form['id']))
  conn.commit()
  return redirect(url_for('display')) 
 elif request.method == "GET":	
  cursor = conn.execute("select * from player_info where id={}".format(id))
  p = [dict(id=row[0],name=row[1],country=row[2],born=row[3],role=row[4],image=row[6]) for row in cursor]
  return render_template('updateForm.html',player = p)
  
@app.route('/player-info/<int:id>')
def player_Info(id):
 cursor = conn.execute("select * from player_info where id={}".format(id)) 
 info = [dict(name=p[1],country=p[2],born=p[3],role=p[4],image=p[6]) for p in cursor]
 print([item for item in info])
 return render_template('player-info.html',info = info)
 
if __name__ == "__main__":
 app.secret_key = os.urandom(12)
 app.run('localhost',port=85)

conn.close()