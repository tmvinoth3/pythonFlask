﻿$(function () {
    var $pick = $("#pick");
    $("#dropdown li a").on("click", function () {
        $pick.text(this.text);
        $('#hidGender').val(this.text);
    });

    $('.sendReqClass').on('click', function () {
        var toFriend = {"toId":$(this).attr('id')};

        $.ajax({
            type: "POST",
            //url: "http://localhost:86/sendRequest",
            url: "{{url_for('sendRequest')}}",
           // url: "/sendRequest",
           // data: toFriend,
            //data: JSON.stringify(toFriend),
           // data: { "toId": JSON.stringify($(this).attr('id')) },
            data: JSON.stringify($(this).attr('id'), null, '\t'),
            contentType: 'application/json;charset=UTF-8',
            success: function (result) {
                console.log(result);
            }
        });
    });

    $('.acceptReqClass').on('click', function () {
        var toFriend = { "toId": $(this).attr('id') };
        $.ajax({
            type: "POST",
            //url: "http://localhost:86/acceptRequest",
            url: "{{url_for('acceptRequest')}}",
           // url: "/acceptRequest",
            //data: toFriend,
            //data: JSON.stringify(toFriend),
            data: JSON.stringify($(this).attr('id'), null, '\t'),
           // data: { "toId": JSON.stringify($(this).attr('id')) },
            contentType: 'application/json;charset=UTF-8',
            success: function (result) {
                console.log(result);
            }
        });
    });
});