from flask import Flask, render_template, render_template_string, abort, request, redirect, url_for
from random import randint
app = Flask(__name__)

booksCollection = {
	'APJ': {
	'author' : 'APJ Abdul Kalam',
	'name' : 'Wing Of Fire'
	},
	'MSD':{
	'author' : 'MS.Dhoni',
	'name' : 'Returns Of CSK'
	}
}
@app.route("/books/")
def getBooks():
	books = ["Wing Of Fire","Return Of CSK"]
	return render_template("books.html",books=books) 
 
@app.route("/book/<string:bookName>") #Accepts only string
def getBook(bookName):
#	if bookName not in booksCollection:
#		abort(404)
	return render_template("bookDetails.html",books=booksCollection[bookName])
	
@app.route("/book/<string:bookName>/edit")
def editBook(bookName):
		abort(401) #Authorization error status

@app.route("/bk/<string:bookName>")
def book(bookName):
	return redirect(url_for('getBook',bookName=bookName),301)

@app.errorhandler(404)
def error(err):
	return render_template("Error.html"),404
	
if __name__ == "__main__":
    app.run('0.0.0.0', port=82)