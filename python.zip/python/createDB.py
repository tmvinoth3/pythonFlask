import sqlite3
from flask import Flask, render_template, request, redirect, url_for
conn = sqlite3.connect('test.db')
print("Opened DB Successfully")
#query = '''
#create table country
#(
#id integer primary key autoincrement,
#name text
#);
#'''
#conn.execute('''
#create table author
#(
#id integer primary key autoincrement,
#name text not null,
#country_id integer
#);
#''')
#
#conn.execute('''
#create table book
#(
#id integer primary key autoincrement,
#name text not null,
#author_id integer,
#isbn text
#);
#''')

#conn.execute(query)
#conn.execute("insert into country (id,name) values(1,'India')")
#conn.execute("insert into country (id,name) values(2,'USA')")
#conn.execute("insert into country (id,name) values(3,'UK')")
#
#conn.execute("insert into author (id,name,country_id) values(1,'Chetan',1)")
#conn.execute("insert into author (id,name,country_id) values(2,'Jeyakandhan',2)")
#conn.execute("insert into author (id,name,country_id) values(3,'Gulu Ezekeil',3)")
#
#conn.commit()
#conn.execute("insert into book (id,name,author_id,isbn) values(1,'Two States',1)")
#conn.execute("insert into book (id,name,author_id,isbn) values(2,'Go Back To Paris',2)")
#conn.execute("insert into book (id,name,author_id,isbn) values(3,'Captain Cool',3)")

#print("Created Table Successfully")
#conn.execute("update country set name='Germany' where id=3")
#conn.execute("delete from country where id=2")

#conn.execute("create table person(name text, country text);");

app = Flask(__name__)



@app.route("/authors/")
def authors():
 cursor = conn.execute("select a.id,a.name,c.name from author a join country c on a.country_id=c.id")
 authors = [dict(id=row[0],name=row[1],country=row[2]) for row in cursor]
 return render_template("authors.html",authors=authors)

@app.before_request 
def beforeRequest():
 print('Before Request Called')
 
@app.route('/display')
def display():
  persons = conn.execute("select * from person")
  person = [dict(id=p[0],name=p[1],country=p[2]) for p in persons]
  return render_template('displayPersons.html',person = person)

@app.route("/form",methods=['POST','GET','PUT'])
def create():
 if request.method == 'GET':
  return render_template('form.html')
 elif request.method == "POST":
  args = {'name' : request.form['name'],'country':request.form['country']}
  conn.execute("insert into person (name,country) values('{}','{}')".format(str(request.form['name']), str(request.form['country'])))
  conn.commit()
  return render_template('form.html')

@app.route("/update",methods=['GET','POST'])
def updateForm():
 if request.method == 'GET':
  return render_template('updateForm.html')
 elif request.method == "POST":
  conn.execute("update person set name='{}',country='{}' where id={}".format(request.form['name'], request.form['country'], request.form['id']))
  conn.commit()
  return redirect(url_for('display')) 

@app.route("/deletePerson/<int:id>")
def delete(id):
 conn.execute("delete from person where id='{}'".format(id))
 conn.commit()
 return redirect(url_for('display'))
 
@app.route("/updatePerson/<int:id>",methods=['POST','GET'])
def update(id):
 if request.method == "POST":
  conn.execute("update person set name='{}',country='{}' where id={}".format(request.form['name'], request.form['country'], request.form['id']))
  conn.commit()
  return redirect(url_for('display')) 
 elif request.method == "GET":	
  cursor = conn.execute("select id,name,country from person where id={}".format(id))
  p = [dict(id=row[0],name=row[1],country=row[2]) for row in cursor]
  return render_template('updateForm.html',person = p)
  
@app.route('/player-info/<int:id>')
def player_Info(id):
 info = conn.execute("select * from player_info where id={}".format(id))	
 return render_template('player_info.html',info = info)
 
if __name__ == "__main__":
 app.run('localhost',port=85)

conn.close()